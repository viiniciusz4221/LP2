﻿namespace ImcCalculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MskTBpeso = new System.Windows.Forms.MaskedTextBox();
            this.LblPeso = new System.Windows.Forms.Label();
            this.LblAltura = new System.Windows.Forms.Label();
            this.MskTBaltura = new System.Windows.Forms.MaskedTextBox();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.BtnCalcular = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.Titulo = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.txtIMC = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // MskTBpeso
            // 
            this.MskTBpeso.Location = new System.Drawing.Point(125, 89);
            this.MskTBpeso.Mask = "900.00";
            this.MskTBpeso.Name = "MskTBpeso";
            this.MskTBpeso.Size = new System.Drawing.Size(197, 22);
            this.MskTBpeso.TabIndex = 0;
            this.MskTBpeso.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.PesoTxt_MaskInputRejected);
            this.MskTBpeso.Validated += new System.EventHandler(this.MskTBpeso_Validated);
            // 
            // LblPeso
            // 
            this.LblPeso.AutoSize = true;
            this.LblPeso.Location = new System.Drawing.Point(75, 92);
            this.LblPeso.Name = "LblPeso";
            this.LblPeso.Size = new System.Drawing.Size(39, 16);
            this.LblPeso.TabIndex = 1;
            this.LblPeso.Text = "Peso";
            // 
            // LblAltura
            // 
            this.LblAltura.AutoSize = true;
            this.LblAltura.Location = new System.Drawing.Point(73, 132);
            this.LblAltura.Name = "LblAltura";
            this.LblAltura.Size = new System.Drawing.Size(41, 16);
            this.LblAltura.TabIndex = 2;
            this.LblAltura.Text = "Altura";
            this.LblAltura.Click += new System.EventHandler(this.label1_Click);
            // 
            // MskTBaltura
            // 
            this.MskTBaltura.Location = new System.Drawing.Point(125, 126);
            this.MskTBaltura.Mask = "0.00";
            this.MskTBaltura.Name = "MskTBaltura";
            this.MskTBaltura.Size = new System.Drawing.Size(197, 22);
            this.MskTBaltura.TabIndex = 1;
            this.MskTBaltura.Validated += new System.EventHandler(this.MskTBaltura_Validated);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Location = new System.Drawing.Point(177, 367);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(86, 71);
            this.BtnLimpar.TabIndex = 3;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // BtnCalcular
            // 
            this.BtnCalcular.Location = new System.Drawing.Point(309, 367);
            this.BtnCalcular.Name = "BtnCalcular";
            this.BtnCalcular.Size = new System.Drawing.Size(86, 71);
            this.BtnCalcular.TabIndex = 2;
            this.BtnCalcular.Text = "Calcular";
            this.BtnCalcular.UseVisualStyleBackColor = true;
            this.BtnCalcular.Click += new System.EventHandler(this.CalcularBtn_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(38, 367);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(86, 71);
            this.btnSair.TabIndex = 4;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Titulo
            // 
            this.Titulo.AutoSize = true;
            this.Titulo.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Titulo.Location = new System.Drawing.Point(67, 9);
            this.Titulo.Name = "Titulo";
            this.Titulo.Size = new System.Drawing.Size(577, 65);
            this.Titulo.TabIndex = 5;
            this.Titulo.Text = "CALCULADORA DE IMC";
            this.Titulo.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 172);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 16);
            this.label1.TabIndex = 7;
            this.label1.Text = "IMC";
            // 
            // txtIMC
            // 
            this.txtIMC.Location = new System.Drawing.Point(125, 169);
            this.txtIMC.Name = "txtIMC";
            this.txtIMC.ReadOnly = true;
            this.txtIMC.Size = new System.Drawing.Size(197, 22);
            this.txtIMC.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(-29, 234);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 69);
            this.label2.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtIMC);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Titulo);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.BtnCalcular);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.MskTBaltura);
            this.Controls.Add(this.LblAltura);
            this.Controls.Add(this.LblPeso);
            this.Controls.Add(this.MskTBpeso);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox MskTBpeso;
        private System.Windows.Forms.Label LblPeso;
        private System.Windows.Forms.Label LblAltura;
        private System.Windows.Forms.MaskedTextBox MskTBaltura;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button BtnCalcular;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Label Titulo;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtIMC;
        private System.Windows.Forms.Label label2;
    }
}

