﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImcCalculadora
{
    public partial class Form1 : Form
    {
        double IMC, peso, altura;
        public Form1()
        {
            InitializeComponent();
        }

        private void PesoTxt_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MskTBpeso_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(MskTBpeso.Text,out peso) || peso <=0)
            {
                errorProvider1.SetError(MskTBpeso, "Numero Inválido!");
                MskTBpeso.Focus();
            }
            else
            {
                errorProvider1.SetError(MskTBpeso, "");
            }
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MskTBaltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(MskTBaltura.Text, out altura) || altura <= 0)
            {
                errorProvider1.SetError(MskTBaltura, "Numero Inválido!");
                MskTBpeso.Focus();
            }
            else
            {
                errorProvider1.SetError(MskTBaltura, "");
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            MskTBaltura.Text = string.Empty;
            MskTBpeso.Text = string.Empty;
            txtIMC.Text = string.Empty;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void CalcularBtn_Click(object sender, EventArgs e)
        {
            IMC = peso / Math.Pow(altura,2);
            IMC = Math.Round(IMC, 1);
            if(IMC < 18.5)
            {
                txtIMC.Text = "Subpeso [" + IMC.ToString() + "]";
            }
            else if(IMC < 25)
            {
                txtIMC.Text = "Normal [" + IMC.ToString() + "]";
            } 
            else if(IMC < 30)
            {
                txtIMC.Text = "Sobrepeso [" + IMC.ToString() + "]";
            }
            else if(IMC < 40)
            {
                txtIMC.Text = "Obesidade [" + IMC.ToString() + "]";
            }
            else
            {
                txtIMC.Text = "Obesidade Mórbida [" + IMC.ToString() + "]";
            }
        }
    }
}
