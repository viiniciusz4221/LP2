﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade4
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out ladoB))
            {
                errorProvider1.SetError(txtLadoB, "Texto Inválido!");
                txtLadoB.Focus();
            }
            else
                errorProvider1.SetError(txtLadoB, "");
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoC.Text, out ladoC))
            {
                errorProvider1.SetError(txtLadoC, "Texto Inválido!");
                txtLadoC.Focus();
            }
            else
                errorProvider1.SetError(txtLadoC, "");
        }
        private void btnCalc_Click(object sender, EventArgs e)
        {
            if ((ladoA >= (ladoB + ladoC)) || (ladoB >= (ladoA + ladoC)) || (ladoC >= (ladoB + ladoA)) || ladoA <= 0 || ladoB <= 0 || ladoC <= 0)
            {
                MessageBox.Show("Este não é um triangulo válido!");
            }
            else
            {
                errorProvider1.SetError(txtLadoC, "");
                if (ladoA == ladoB && ladoA == ladoC)
                {
                    MessageBox.Show("Triangulo Equilatero!");
                }
                else
                {
                    if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC)
                    {
                        MessageBox.Show("Triangulo Isósceles!");
                    }
                    else
                    {
                        MessageBox.Show("Triângulo Escaleno!");
                    }
                }    
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out ladoA))
            {
                errorProvider1.SetError(txtLadoA, "Texto Inválido!");
                txtLadoA.Focus();
            }
            else
                errorProvider1.SetError(txtLadoA, "");

        }
    }
}
