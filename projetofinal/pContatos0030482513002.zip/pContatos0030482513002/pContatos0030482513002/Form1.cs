﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace pContatos0030482513002
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try

              //  Data Source = LAPTOP - DVR2FTRD\SQLEXPRESS; Initial Catalog = BD; Integrated Security = True; Pooling = False; Encrypt = True; Trust Server Certificate = True
            {
                //Data Source = LAPTOP - DVR2FTRD\SQLEXPRESS; Initial Catalog = BD; Integrated Security = True; Pooling = False; Encrypt = True; Trust Server Certificate = True
                conexao = new SqlConnection("Data Source=LAPTOP-DVR2FTRD\\SQLEXPRESS;Initial Catalog=BD; Integrated Security = True");
                conexao.Open();
            }
            catch(SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Outros Erros =/" + ex.Message);
            }
            
        }

        private void cadastroContatosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmContato>().Count() > 0) // Testa se o formulário 2 já foi criado na memória, se sim, traz para frente
            {
                Application.OpenForms["frmContato"].BringToFront();
            }
            else
            {
                frmContato FRMC = new frmContato();
                FRMC.MdiParent = this; // Parent = Pai, obtém o pai dele. This é o formulário em questão, ou seja, form1
                FRMC.WindowState = FormWindowState.Maximized; // Em qual estado ele vai abrir (ficará maximizado dentro do primeiro)
                FRMC.Show();
            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<sobre>().Count() > 0) // Testa se o formulário 2 já foi criado na memória, se sim, traz para frente
            {
                Application.OpenForms["sobre"].BringToFront();
            }
            else
            {
                sobre FRMS = new sobre();
                FRMS.MdiParent = this; // Parent = Pai, obtém o pai dele. This é o formulário em questão, ou seja, form1
                FRMS.WindowState = FormWindowState.Maximized; // Em qual estado ele vai abrir (ficará maximizado dentro do primeiro)
                FRMS.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
