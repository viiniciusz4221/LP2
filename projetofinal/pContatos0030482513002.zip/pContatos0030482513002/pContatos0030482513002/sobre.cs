﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pContatos0030482513002
{
    public partial class sobre : Form
    {
        public sobre()
        {
            InitializeComponent();
        }

        private void btnSairSobre_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
