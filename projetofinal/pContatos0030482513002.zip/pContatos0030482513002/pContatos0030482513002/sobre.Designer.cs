﻿namespace pContatos0030482513002
{
    partial class sobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sobre));
            this.lblCriadoPor = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblNome2 = new System.Windows.Forms.Label();
            this.lblNome3 = new System.Windows.Forms.Label();
            this.btnSairSobre = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCriadoPor
            // 
            this.lblCriadoPor.AutoSize = true;
            this.lblCriadoPor.BackColor = System.Drawing.Color.Transparent;
            this.lblCriadoPor.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCriadoPor.Location = new System.Drawing.Point(443, 82);
            this.lblCriadoPor.Name = "lblCriadoPor";
            this.lblCriadoPor.Size = new System.Drawing.Size(114, 22);
            this.lblCriadoPor.TabIndex = 0;
            this.lblCriadoPor.Text = "CRIADO POR:";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.BackColor = System.Drawing.Color.Transparent;
            this.lblNome.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(224, 116);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(633, 37);
            this.lblNome.TabIndex = 2;
            this.lblNome.Text = "VINICIUS ALEXANDRE MATHEUS ANTUNES";
            // 
            // lblNome2
            // 
            this.lblNome2.AutoSize = true;
            this.lblNome2.BackColor = System.Drawing.Color.Transparent;
            this.lblNome2.Font = new System.Drawing.Font("Microsoft Tai Le", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome2.Location = new System.Drawing.Point(303, 171);
            this.lblNome2.Name = "lblNome2";
            this.lblNome2.Size = new System.Drawing.Size(408, 35);
            this.lblNome2.TabIndex = 2;
            this.lblNome2.Text = "KAUAN TEIXEIRA DOS ANJOS";
            // 
            // lblNome3
            // 
            this.lblNome3.AutoSize = true;
            this.lblNome3.BackColor = System.Drawing.Color.Transparent;
            this.lblNome3.Font = new System.Drawing.Font("Microsoft Tai Le", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblNome3.Location = new System.Drawing.Point(312, 223);
            this.lblNome3.Name = "lblNome3";
            this.lblNome3.Size = new System.Drawing.Size(373, 35);
            this.lblNome3.TabIndex = 2;
            this.lblNome3.Text = "WESLEY PIRES DE CAMPOS";
            // 
            // btnSairSobre
            // 
            this.btnSairSobre.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSairSobre.Location = new System.Drawing.Point(447, 415);
            this.btnSairSobre.Name = "btnSairSobre";
            this.btnSairSobre.Size = new System.Drawing.Size(132, 68);
            this.btnSairSobre.TabIndex = 1;
            this.btnSairSobre.Text = "Sair";
            this.btnSairSobre.UseVisualStyleBackColor = true;
            this.btnSairSobre.Click += new System.EventHandler(this.btnSairSobre_Click);
            // 
            // sobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1095, 516);
            this.Controls.Add(this.lblNome3);
            this.Controls.Add(this.lblNome2);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.btnSairSobre);
            this.Controls.Add(this.lblCriadoPor);
            this.Name = "sobre";
            this.Text = "sobre";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCriadoPor;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblNome2;
        private System.Windows.Forms.Label lblNome3;
        private System.Windows.Forms.Button btnSairSobre;
    }
}