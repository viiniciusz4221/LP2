﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pestoque2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[,] Estoque = new int[4,4];
            int somatotal = 0;

            for (int i = 0; i < 4; i++)
            {
                int somaauxiliar = 0;
                for(int j = 0; j < 4; j++)
                {
                    if(!int.TryParse(Interaction.InputBox($"Digite a qtde do Produto {i+1} na semana {j+1}: ", "Entrada de Dados"), out Estoque[i,j]) || Estoque[i,j] < 0)
                    {
                        MessageBox.Show("Entrada inválda!");
                        j--;
                    }
                    else
                    {
                        lstBoxEstoque.Items.Add($"Total Entradas do Produto {i + 1} Semana {j + 1} - {Estoque[i, j]}");
                        somaauxiliar += Estoque[i, j];
                        somatotal += Estoque[i, j];
                    }

                    if(j == 3)
                    {
                        lstBoxEstoque.Items.Add($">>Total Entradas do Produto {i + 1}:               {somaauxiliar}");
                        lstBoxEstoque.Items.Add("------------------------------------------------------------------------");
                        somaauxiliar = 0;
                    }
                }
            }


            lstBoxEstoque.Items.Add($">>Total Geral Entradas:                          {somatotal}");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstBoxEstoque.Items.Clear();
        }
    }
}
